
from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from random import choice

app = Flask(__name__)
app.secret_key = 'magie-secrete'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///menteur_magique.db'
db = SQLAlchemy(app)

class Player(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    story = db.Column(db.String(500))
    is_menteur = db.Column(db.Boolean, default=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start', methods=['POST'])
def start_game():
    # Simuler des joueurs
    players = ['Emma', 'Léo', 'Clara', 'Lucas']
    mentir = choice(players)
    db.drop_all()
    db.create_all()
    for p in players:
        db.session.add(Player(name=p, is_menteur=(p == mentir)))
    db.session.commit()
    return redirect(url_for('game'))

@app.route('/game')
def game():
    players = Player.query.all()
    theme = "Une rencontre étrange"
    return render_template('game.html', players=players, theme=theme)

if __name__ == '__main__':
    app.run(debug=True)
